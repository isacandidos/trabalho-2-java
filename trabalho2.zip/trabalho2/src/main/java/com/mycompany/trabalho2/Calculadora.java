/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho2;

/**
 *
 * @author isadora
 */
public class Calculadora {
    private int num1;
    private int num2;
    
    

    //construtor
    public Calculadora(int num1, int num2) {
        this.num1 = num1;
        this.num2 = num2;
    }
    
    //get e set Num1
    public int getNum1() {
        return num1;
    }

    public void setNum1(int num1) {
        this.num1 = num1;
    }
    
    //get e set Num2
    public int getNum2() {
        return num2;
    }

    public void setNum2(int num2) {
        this.num2 = num2;
    }
    
    //soma
    public int some() {
        return num1 + num2;
    }
   
    // subtraçao 
    public int subtraia(){
      return num2 - num1;
    }
   //divisao
    public int divida(){
        if (num2 != 0) {
            return num1 / num2;
        } 
        else{
            System.out.println("Divisão por zero não é permitido");}
        return 0;
}
    
    //multiplicaçao
    public int multiplique(){
        return num1 * num2;
    }
}
