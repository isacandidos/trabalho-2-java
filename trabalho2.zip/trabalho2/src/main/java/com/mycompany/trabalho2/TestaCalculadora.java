/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalho2;

/**
 *
 * @author isadora
 */


 import java.util.Scanner;

public class TestaCalculadora {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String operador;
        
        while (true) {
            System.out.println("Digite o operador (+, -, /, * ou '.' para sair): ");
            operador = scanner.nextLine();
            
            if (operador.equals(".")) {
                break; // Encerra o loop se o usuário digitar ponto
            }

            System.out.println("Digite o primeiro número: ");
            int num1 = Integer.parseInt(scanner.nextLine());

            System.out.println("Digite o segundo número: ");
            int num2 = Integer.parseInt(scanner.nextLine());

            Calculadora calculadora = new Calculadora(num1, num2);
            int resultado = 0;
            boolean operacaoValida = true;

            switch (operador) {
                case "+":
                    resultado = calculadora.some();
                    break;
                case "-":
                    resultado = calculadora.subtraia();
                    break;
                case "/":
                    try {
                        resultado = calculadora.divida();
                    } catch (ArithmeticException e) {
                        System.out.println(e.getMessage());
                        operacaoValida = false;
                    }
                    break;
                case "*":
                    resultado = calculadora.multiplique();
                    break;
                default:
                    System.out.println("Operador inválido.");
                    operacaoValida = false;
            }

            if (operacaoValida) {
                System.out.println("Resultado: " + resultado);
            }
        }

        scanner.close();
        System.out.println("Calculadora encerrada.");
    }
}


